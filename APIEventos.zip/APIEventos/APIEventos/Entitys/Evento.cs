﻿namespace APIEventos.Entitys
{
    public class Evento
    {
        public int Id { get; set; }
        public required string Titulo { get; set; }
        public required string Descripcion { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public int TipoEvento { get; set; }
    }
}
