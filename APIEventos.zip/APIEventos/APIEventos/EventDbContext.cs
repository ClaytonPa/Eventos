﻿using APIEventos.Entitys;
using Microsoft.EntityFrameworkCore;

namespace APIEventos
{
    public class EventDbContext : DbContext
    {
        public EventDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Evento> Eventos { get; set; }
    }
}
