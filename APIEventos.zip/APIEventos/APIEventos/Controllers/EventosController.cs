﻿using APIEventos.Entitys;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APIEventos.Controllers
{
    [Route("api/eventos")]
    public class EventosController : ControllerBase
    {
        private readonly EventDbContext context;

        public EventosController(EventDbContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<List<Evento>> Get()
        {
            return await context.Eventos.ToListAsync();
        }

        [HttpGet("{id:int}", Name = "ObtenerEventoPorId")]
        public async Task<ActionResult<Evento>> Get(int id)
        {
            var evento = await context.Eventos.FirstOrDefaultAsync(x => x.Id == id);

            if (evento == null)
            {
                return NotFound();
            }
            return Ok(evento);
        }

        [HttpPost]
        public async Task<CreatedAtRouteResult> Post([FromBody] Evento evento)
        {
            context.Add(evento);
            await context.SaveChangesAsync();
            return CreatedAtRoute("ObtenerEventoPorId", new { id = evento.Id }, evento);
        }
        [HttpPut("{id:int}")]
        public async Task<ActionResult> Put(int id, [FromBody] Evento evento)
        {
            var EventoExisting = await context.Eventos.AnyAsync(x => x.Id == id);

            if (!EventoExisting)
            {
                return NotFound();
            }
            evento.Id = id;
            context.Update(evento);
            await context.SaveChangesAsync();
            return NoContent();
        }
        [HttpDelete("{id:int}")]
        public async Task<ActionResult> Delete(int id) 
        { 
            var Eliminado = await context.Eventos.Where(x => x.Id == id).ExecuteDeleteAsync();

            if(Eliminado == 0)
            {
                return NotFound();
            }
            return NoContent();
        }



    }
}
